import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class ConvertirTabla extends JFrame{
    private JTextField txtNomTabla;
    private JTextField txtNumeros;
    private JPanel panelMain;
    private JTextField txtBuscar;
    private JButton btnBuscar;
    private JButton btnEjecutar;
    private JCheckBox chbAgreAtri;
    private String nomTabla, campNumeros, direccion, val, mensaje;



    public ConvertirTabla() {
        btnBuscar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFileChooser fc = new JFileChooser();

                int seleccion = fc.showOpenDialog(fc);

                if(seleccion == JFileChooser.APPROVE_OPTION){

                    File fichero = fc.getSelectedFile();
                    txtBuscar.setText(fichero.getAbsolutePath());
                    direccion = fichero.getAbsolutePath();

                }
            }
        });
        btnEjecutar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    nomTabla = txtNomTabla.getText().toUpperCase();
                    campNumeros = txtNumeros.getText();
                    boolean checkbox = chbAgreAtri.isSelected();

                    Date d = new Date();
                    DateFormat df = new SimpleDateFormat("yyyyMMdd");

                    XSSFSheet hoja = null;
                    FileWriter escribir = null;

                    //Validando que exista una direccion de archivo
                    if(direccion == null || nomTabla.equals("")){
                        JOptionPane.showMessageDialog(null,"Debe llenar los " +
                                "campos Nombre Tabla y Archivo.","Error Campos Vacios", JOptionPane.ERROR_MESSAGE);
                    }else {
                        FileInputStream archivo = new FileInputStream(direccion);
                        XSSFWorkbook libro =  new XSSFWorkbook(archivo);
                        hoja = libro.getSheetAt(0);

                        File file = new File(nomTabla+"-"+df.format(d)+".txt");
                        escribir = new FileWriter(file, false);
                        int numero_filas = hoja.getLastRowNum();
                        int numero_columnas = 0;
                        for(int i = 0; i <= numero_filas; i++) {
                            Row fila = hoja.getRow(i);

                            numero_columnas = fila.getLastCellNum();
                        }

                        String[][] lista_campos = new String[numero_filas+1][numero_columnas];
                        String[] seleccionColum = campNumeros.replace(" ", "").split(",");
                        String mensajeCampos = "", mensajeValor = "";
                        boolean columnasVacia = campNumeros.equals("");

                        //Columna -1
                        if(!columnasVacia){
                            int[] columna = new int[seleccionColum.length];
                            for (int i = 0; i < columna.length; i++) {
                                columna[i] = Integer.parseInt(seleccionColum[i]) -1;
                                seleccionColum[i] = String.valueOf(columna[i]);
                            }
                        }


                        // Leer filas
                        for(int i = 0; i < numero_filas+1; i++){
                            Row fila = hoja.getRow(i);

                            numero_columnas = fila.getLastCellNum();

                            // Leer columnas
                            for(int j = 0; j < numero_columnas; j++){
                                Cell celda = fila.getCell(j);
                                DataFormatter formatter = new DataFormatter();
                                val = formatter.formatCellValue(celda) + "";

                                lista_campos[i][j] = val;


                            }

                        }

                        //Convirtiendo a sentencia sql
                        for(int i = 1; i < lista_campos.length; i++){
                            for(int j = 0; j < lista_campos[i].length; j++) {

                                mensajeCampos += lista_campos[0][j] + ", ";

                                if(columnasVacia){
                                    mensajeValor += "'"+lista_campos[i][j]+ "', ";
                                }else if(columnaExite(j, seleccionColum)){
                                    mensajeValor += lista_campos[i][j]+ ", ";

                                }else{
                                    mensajeValor += "'"+lista_campos[i][j]+ "', ";
                                }
//                            if(columnaExite(j, seleccionColum) && !columnasVacia){
//                                mensajeValor += lista_campos[i][j]+ ", ";
//                            }else {
//                                mensajeValor += "'"+lista_campos[i][j]+ "', ";
//                            }

                            }

                            mensajeCampos = mensajeCampos.substring(0,mensajeCampos.length() - 2);
                            mensajeValor = mensajeValor.substring(0, mensajeValor.length() - 2);

//                            mensaje = "INSERT INTO " + nomTabla +
//                                    "("+mensajeCampos.toUpperCase()+") \nVALUES ("+mensajeValor.toUpperCase()+")\n";
                            if(checkbox){
                                mensaje = "INSERT INTO " + nomTabla +
                                        "("+mensajeCampos.toUpperCase()+") \nVALUES ("+mensajeValor.toUpperCase()+")\n";
                            }else {
                                mensaje = "INSERT INTO " + nomTabla +"\nVALUES ("+mensajeValor.toUpperCase()+")\n";
                            }

                            mensajeValor = "";
                            mensajeCampos = "";
                            escribir.write(mensaje+"\n");
                        }
                        escribir.close();
                    }





                } catch (IOException ex) {
                    throw new RuntimeException(ex);
                }
            }
        });
    }
    public boolean columnaExite(int j, String[] arreglo){
        boolean b = false;
        for (String s : arreglo) {
            if (Integer.parseInt(s) == j) {
                b = true;
            }
        }
        return b;
    }

    public static void main(String[] args){
        JFrame frame = new JFrame("Convertir Tabla");
        frame.setContentPane(new ConvertirTabla().panelMain);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 200);
        frame.setLocationRelativeTo(null);
        frame.pack();
        frame.setVisible(true);
    }
}
